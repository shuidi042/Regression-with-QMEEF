%% 1. The code to implement the fixed-point iterative algorithm under Kernel Mean p-Power Error (KMPE) cirterion
%% 2. The definition of KMPE can refer to "Chen B, Xing L, Wang X, Qin J, Zheng N. Robust Learning With Kernel Mean p-Power Error Loss. 
%%    IEEE Transactions on Cybernetics. 2018, 48(7): 2101-2113."

function W = KMPE_Batch(U, Y, regularization, p, sigma, maxIter)
%output:
    % W: the weight vector needed to be optimized
%input:
    % U： training input (trainNum * inputDim)
    % Y:  training output (trainNum * 1)
    % regularization: a positive constant for regularization, such as 1e-3
    % p: the order of KMPE
    % sigma: kernel parameter of KMPE
    % maxIter: maximum number of iterations
    
    [trainNum,dimension] = size(U);
    class = size(Y,2);
    W =zeros(dimension,class);
    temp=regularization*eye(dimension);
    for iter=1:maxIter 
        W1=W;
        E=Y-U*W;%trainNum*class
        KSIGMA = exp(- E.^2/(2*sigma^2) );
        FAI = (1-KSIGMA).^((p-2)/2).*KSIGMA;
        LAMBDA=spdiags(FAI, 0,trainNum,trainNum);
        L1=U'*LAMBDA*U;
        L2=U'*LAMBDA*Y;
        clear E LAMBDA;
        W = (L1+temp) \ ( L2);
            
        %%%%% stopping criterion
        if norm(W-W1)^2/norm(W1)^2<=1e-10 
            break;
        end      
        
        clear L1 L2 X ;               
    end
end