%% 1. The code to implement the fixed-point iterative algorithm under Maximum Correntropy Criterion with Cariable Center(MCC-VC)
%% 2. The definition of MCC-VC can refer to "Chen B, Wang X, Li Y, Principe JC. Maximum correntropy criterion with variable center. 
%%    IEEE Signal Processing Letters. 2019, 26(8): 1212-1216."

function W = MCCVC_Batch(U, Y, regularization, center, kermcc, maxIter)
%output:
    % W: the weight vector needed to be optimized
%input:
    % U： training input (trainNum * inputDim)
    % Y:  training output (trainNum * 1)
    % regularization: a positive constant for regularization, such as 1e-3
    % center: center of the Gaussian kernel in MCCVC
    % kermcc: kernel parameter of the Gaussian kernel in MCCVC
    % maxIter: maximum number of iterations
    
    [trainNum,dimension] = size(U);
    class = size(Y,2);
    W =zeros(dimension,class);
    temp=regularization*eye(dimension);
    % begin iteration
    for iter=1:maxIter 
        W1=W;
        E=Y-U*W;%trainNum*class
        EV = E-repmat(center,trainNum, class);
        X=EV.^2;
        clear  E ;
        LAMBDA=spdiags(1/(sqrt(2*pi)*kermcc)*exp(-X/(2*kermcc^2)), 0, trainNum, trainNum);
        L1=U'*LAMBDA*U;
        L2=U'*LAMBDA*(Y-center);
        clear X LAMBDA;
        W = (L1+temp) \ ( L2);
           
        %%%%% stopping criterion
        if norm(W-W1)^2/norm(W1)^2<=1e-10 
            break;
        end      
        
        clear L1 L2 X ;               
    end
end

