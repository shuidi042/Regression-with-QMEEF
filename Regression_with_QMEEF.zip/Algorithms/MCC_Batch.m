%% 1. The code to implement the fixed-point iterative algorithm under maximum correntropy criterion (MCC)
%% 2. The definition of correntropy can refer to "Liu W, Pokharel PP, Principe JC. Correntropy: Properties and Applications in Non-Gaussian Signal Processing. 
%%    IEEE Transactions on Signal Processing. 2007, 55(11): 5286-5298."

function W = MCC_Batch(U, Y, regularization, kermcc, maxIter)
%output:
    % W: the weight vector needed to be optimized
%input:
    % U： training input (trainNum * inputDim)
    % Y:  training output (trainNum * 1)
    % regularization: a positive constant for regularization, such as 1e-3
    % kermcc: kernel parameter of MCC 
    % maxIter: maximum number of iterations
    
    [trainNum,dimension] = size(U);
    class = size(Y,2);
    W =zeros(dimension,class);
    temp=regularization*eye(dimension);
    for iter=1:maxIter 
        W1=W;
        E=Y-U*W;%trainNum*class
        X = E.^2;
        clear  E ;
        LAMBDA=spdiags(exp(-X/(2*kermcc^2))/sqrt(2*pi*kermcc^2), 0,trainNum,trainNum);
        L1=U'*LAMBDA*U;
        L2=U'*LAMBDA*Y;
        clear X LAMBDA;
        W = (L1+temp) \ ( L2);
            
        %%%%% stopping criterion
        if norm(W-W1)^2/norm(W1)^2<=1e-10 
            break;
        end      
        
        clear L1 L2 X ;               
    end
end