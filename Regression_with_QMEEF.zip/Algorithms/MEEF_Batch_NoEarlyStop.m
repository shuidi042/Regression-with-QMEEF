%% A special case to implement the fixed-point iterative algorithm under MEEF without eraly stopping criterion and quantization

function W = MEEF_Batch_NoEarlyStop(U, Y, regularization, lambda, kermcc, kermee, maxIter)
%output:
    % W: the weight vector needed to be optimized
%input:
    % U： training input (trainNum * inputDim)
    % Y:  training output (trainNum * 1)
    % regularization: a positive constant for regularization, such as 1e-3
    % lambda: mixture parameter in MEEF
    % kermcc and kermee: kernel parameters in MEEF
    % epsilon: a threshold to perform quantization operator
    % maxIter: maximum number of iterations
    
    [trainNum, dimension] = size(U);
    class = size(Y,2);
    W = zeros(dimension,class);
    temp = regularization *eye(dimension);
    for iter = 1: maxIter
       %% compute the errors
        W1=W;
        EE=Y-U*W;
       %% 
        dicMem = EE';
        nbMem = ones(trainNum, 1)';
       %% compute tau1, tau2, and tau3
        tau1 =  zeros(trainNum, 1);
        tau2 =  zeros(trainNum, 1);
        for i=1:1:size(nbMem,2)% this computational mode is vey skillful, since only one sum operator is involved
            tmp = nbMem(i)*exp(-(EE-dicMem(i)).^2/(2*kermee^2))/sqrt(2*pi*kermee^2);
            tau1 = tau1 + tmp;
            tau2 = tau2 + dicMem(i) * tmp;
        end
        tau1 = lambda/(kermee^2) * tau1;
        tau2 = lambda/(kermee^2) * tau2;
        tau3 = (1-lambda)/(kermcc^2) * exp(-EE.^2/(2*kermcc^2))/sqrt(2*pi*kermcc^2);
        clear E dicMem nbMem
       %% compute LAM and TT
        LAM = spdiags(tau1 + tau3, 0, trainNum, trainNum); %For reducing the memory expense
        clear  tmp2;
        TT = tau2;
        clear  tau1 tau2 tau3;
       %% compute the weights
        R = U'* LAM * U + temp;
        P = U'* LAM * Y - U'* TT;
        clear LAM  TT
        W = R\P;
        clear R P
        
       %% stopping criterion
        tau_0 = 0;% this means that no early stopping criterion is adopted 
        if norm(W-W1)^2/norm(W1)^2<tau_0
            break;
        end                   
    end
end


