%% 1. The code to implement the fixed-point iterative algorithm under Maximum Mixture Correntropy Criterion (MMCC)
%% 2. The definition of MCC-VC can refer to "Chen B, Wang X, Lu N, Wang S, Cao J, Qin J. Mixture Correntropy for Robust Learning. 
%%    Pattern Recognition. 2018, 79: 318-327."

function W = MMCC_Batch(U,Y,regularization,kermcc1,kermcc2,alpha,maxIter)
%output:
    % W: the weight vector needed to be optimized
%input:
    % U： training input (trainNum * inputDim)
    % Y:  training output (trainNum * 1)
    % regularization: a positive constant for regularization, such as 1e-3
    % kermcc1 and kermcc2: kernel parameters in MMCC
    % alpha: mixture parameter in MMCC 
    % maxIter: maximum number of iterations
    
    [trainNum,dimension] = size(U);
    class = size(Y,2);
    W = zeros(dimension,class);
    temp=regularization*eye(dimension);
    for i=1:maxIter
        %train  
        W1=W;
        E=Y-U*W;%trainNum*class
        X=E.^2;
        LAMBDA=spdiags(alpha/kermcc1^2*exp(-X/(2*kermcc1^2)) + (1-alpha)/kermcc2^2*exp(-X/(2*kermcc2^2)),0,trainNum,trainNum); %For reducing the memory expense
        clear X E;
        L1=U'*LAMBDA*U;
        L2=U'*LAMBDA*Y;
        clear LAMBDA;
        W = (L1+temp) \ ( L2);

        
        %%%%% stopping criterion
        if norm(W-W1)^2/norm(W1)^2<=1e-10
            break;
        end     
        
        clear L1 L2;               
    end
    %plot(R)
end
