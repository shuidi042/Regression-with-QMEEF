%% The code to implement the regularized least-squares (non-iterative) algorithm under the Mean Square Error (MSE) criterion 

function W=MSE_Batch(U, Y,  regularization)
%output:
    % W: the weight vector needed to be optimized
%input:
    % U�� training input (trainNum * inputDim)
    % Y:  training output (trainNum * 1)
    % regularization: a positive constant for regularization, such as 1e-3
    
    dimension=size(U,2);
    %% training
    W=(U'*U+regularization*eye(dimension))\(U'*Y);

end

