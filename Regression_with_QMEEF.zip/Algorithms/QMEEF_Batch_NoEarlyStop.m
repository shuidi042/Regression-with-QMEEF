%% A special case to implement the fixed-point iterative algorithm under QMEEF without eraly stopping criterion

function W = QMEEF_Batch_NoEarlyStop(U, Y, regularization, lambda, kermcc, kerqmee, epsilon, maxIter)
%output:
    % W: the weight vector needed to be optimized
%input:
    % U： training input (trainNum * inputDim)
    % Y:  training output (trainNum * 1)
    % regularization: a positive constant for regularization, such as 1e-3
    % lambda: mixture parameter in QMEEF
    % kermcc and kerqmee: kernel parameters in QMEEF
    % epsilon: a threshold to perform quantization operator
    % maxIter: maximum number of iterations
    
    [trainNum, dimension] = size(U);
    class = size(Y,2);
    W = zeros(dimension,class);
    temp = regularization *eye(dimension);
    %% the additional kernel size to perform quantization operator is directly set the same as kerqmee in our experiments
    sigma_q = kerqmee; 
    for iter = 1: maxIter
       %% compute the errors
        W1=W;
        EE=Y-U*W;
       %% quantized method (see Algoritm 1 of the paper)
        if epsilon ~= 0
            [dicMem, nbMem] = MVQ(EE, epsilon, sigma_q);        
        elseif epsilon == 0
           dicMem = EE';
           nbMem = ones(trainNum, 1)';
        end
       %% compute tau1, tau2, and tau3
        tau1 =  zeros(trainNum, 1);
        tau2 =  zeros(trainNum, 1);
        for i=1:1:size(nbMem,2)
            tmp = nbMem(i)*exp(-(EE-dicMem(i)).^2/(2*kerqmee^2))/sqrt(2*pi*kerqmee^2);
            tau1 = tau1 + tmp;
            tau2 = tau2 + dicMem(i) * tmp;
        end
        tau1 = lambda/(kerqmee^2) * tau1;
        tau2 = lambda/(kerqmee^2) * tau2;
        tau3 = (1-lambda)/(kermcc^2) * exp(-EE.^2/(2*kermcc^2))/sqrt(2*pi*kermcc^2);
        clear E dicMem nbMem
       %% compute LAM and TT
        LAM = spdiags(tau1 + tau3, 0, trainNum, trainNum); %For reducing the memory expense
        clear  tmp2;
        TT = tau2;
        clear  tau1 tau2 tau3;
       %% compute the weights
        R = U'* LAM * U + temp;
        P = U'* LAM * Y - U'* TT;
        clear LAM  TT
        W = R\P;
        clear R P
        
       %% stopping criterion
        tau_0 = 0;% this means that no early stopping criterion is adopted 
        if norm(W-W1)^2/norm(W1)^2<tau_0
            break;
        end                  
    end
end


