%% 1. The code to implement the fixed-point iterative algorithm under Quantized Minimum Error Entropy Criterion (QMEE)
%% 2. The definition of MCC-VC can refer to "Chen B, Xing L, Zheng N, Pr��ncipe JC. Quantized Minimum Error Entropy Criterion. 
%%    IEEE Transactions on Neural Networks and Learning Systems. 2019, 30(5): 1370-1380."

function W = QMEE_Batch(U, Y, regularization, sigma, epsilon, maxIter)
%output:
    % W: the weight vector needed to be optimized
%input:
    % U�� training input (trainNum * inputDim)
    % Y:  training output (trainNum * 1)
    % regularization: a positive constant for regularization, such as 1e-3
    % sigma: kernel parameter of in QMEE 
    % epsilon: a threshold to perform quantization operator
    % maxIter: maximum number of iterations
    
    [trainNum,dimension] = size(U);
    class = size(Y,2);
    W = zeros(dimension,class);
    temp=regularization*eye(dimension);
%     sigma=sqrt(2)*sigma;
    for iter=1:maxIter
        % compute the errors
        W1=W;
        E=Y-U*W;
        %%%%% quantization operator
        dicMem=[]; %  a collection storing dictionary members (dictionary of error)
        nbMem=[]; % a collection storing the number of each dictionary member family (number of dictionary member��
        for i=1:1:trainNum
            if i==1
                dicMem=[dicMem,E(i)];
                nbMem=[nbMem,1];
            else
               E_temp=(dicMem-repmat(E(i),size(dicMem,1),size(dicMem,2))).^2;  %square of the distance
               [minDis,minLocal]=min(E_temp);       
                if minDis>epsilon^2  %square of the threshold
                    dicMem=[dicMem,E(i)];
                    nbMem=[nbMem,1];
                else     
                    nbMem(minLocal)= nbMem(minLocal)+1;      
                end
            end
        end
        
        %%%%%%%%%%%%%%%%%%%%%%  compute the weights: standard manner
        L1=zeros(dimension,dimension);
        L2=zeros(1,dimension);
        for i=1:1:size(nbMem,2)
%             Delta=diag(nbMem(i)*exp(-(E-dicMem(i)).^2/(2*sigma^2)));
            Delta=spdiags(nbMem(i)*exp(-(E-dicMem(i)).^2/(2*sigma^2))/sqrt(2*pi*sigma^2), 0, trainNum, trainNum);
            L1=L1+U'*Delta*U;
            L2=L2+( U'*Delta*(Y-dicMem(i)) )';
        end
        W=(L1+temp)\L2';
        
        %%%%% stopping criterion
        if norm(W-W1)^2/norm(W1)^2<=1e-10 
            break;
        end      
        
        clear L1 L2;               
    end
    %plot(R)
end

