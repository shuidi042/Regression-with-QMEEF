function [TrainTime, TestTime, TrainRMSE, TestRMSE, RWEP]= Linear_MEEF_NoEarlyStop(train_x, train_y, test_x, test_y, regularization, lambda, kermcc, kermee, maxIter)
%output:
    %TrainTime: training time 
    %TestTime: test time
    %TrainRMSE: training RMSE 
    %TestRMSE: test RMSE
    %RWEP: root weight error power
%input:
    % train_x�� training input (trainNum * inputDim)
    % train_y:   training output (trainNum * 1)
    % test_x:    test input ( testNum * inputDim)
    % test_y:    test output (testNum * 1)
    % regularization: a positive constant for regularization, such as 1e-3
    % lambda: mixture parameter in MEEF
    % kermcc and kermee: kernel parameters in MEEF
    % maxIter: maximum iteration number, such as 50
    
    [trainNum,~] = size(train_x);
    [testNum,~] = size(test_x);
    %% training
    tic;
    W = MEEF_Batch_NoEarlyStop(train_x, train_y, regularization, lambda, kermcc, kermee, maxIter);
    TrainTime=toc;
    
    %% compute the training accuracy 
    Y_train=train_x*W;
    E_train=train_y-Y_train;
    TrainRMSE=sqrt(sum(E_train.^2,1)/trainNum);
    
   %% compute the testing accuracy 
    tic;
    if isempty(test_x) && isempty(test_y)
        TestRMSE= [];
    else
        Y_test=test_x*W;
        E_test=test_y-Y_test;
        TestRMSE=sqrt(sum(E_test.^2,1)/testNum);
    end
    %
    W_opt= [2, 1]';
    RWEP = sqrt(1/2 * norm(W - W_opt)^2);
    TestTime=toc;
    
end

