function [TrainTime, TestTime, TrainRMSE, TestRMSE, MEP]= Linear_MSE(train_x, train_y, test_x, test_y,  regularization)
%output:
    %TrainTime: training time 
    %TestTime: test time
    %TrainRMSE: training RMSE 
    %TestRMSE: test RMSE
    %TestMAE: test MAE
%input:
    % train_x�� training input (trainNum * inputDim)
    % train_y:   training output (trainNum * 1)
    % test_x:    test input ( testNum * inputDim)
    % test_y:    test output (testNum * 1)
    % regularization: a positive constant for regularization, such as 1e-3
    [trainNum,~] = size(train_x);
    [testNum,~] = size(test_x);
    %% training
    tic;
    W=MSE_Batch(train_x, train_y,  regularization);
    TrainTime=toc;
    
    %% compute the training accuracy 
    Y_train=train_x*W;
    E_train=train_y-Y_train;
    TrainRMSE=sqrt(sum(E_train.^2,1)/trainNum);
    
   %% compute the testing accuracy 
    tic;
    if isempty(test_x) && isempty(test_y)
        TestRMSE= [];
    else
        Y_test=test_x*W;
        E_test=test_y-Y_test;
        TestRMSE=sqrt(sum(E_test.^2,1)/testNum);
    end
    %
    W_opt= [2, 1]';
    MEP = sqrt(1/2 * norm(W - W_opt)^2);
    TestTime=toc;
   
end

