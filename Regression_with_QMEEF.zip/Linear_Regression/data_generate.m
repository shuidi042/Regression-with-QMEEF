function [data_x, data_y] = data_generate(trainNum)
    W_opt=[2,1]';
    % training data
    x1=2*(2*rand(trainNum,1)-1)';
    x2=2*(2*rand(trainNum,1)-1)';
    data_x=[x1', x2'];
    data_y=data_x*W_opt;
    clear x1  x2 
%     % testing data
%     x1=2*(2*rand(testNum,1)-1)';
%     x2=2*(2*rand(testNum,1)-1)';
%     test_x=[x1', x2'];
%     test_y=test_x*W_opt;
%     clear x1  x2
end