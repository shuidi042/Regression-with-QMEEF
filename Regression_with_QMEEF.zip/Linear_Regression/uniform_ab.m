function  y= uniform_ab(a,b, num)
    y = a + (b-a)*rand(num, 1);
end

