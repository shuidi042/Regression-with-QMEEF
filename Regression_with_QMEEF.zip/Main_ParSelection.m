%%  1. This code is used to perform the parameters selection of different methods, and this process
%%     can be time consuming
%%  2. You can alternatively use the parameters we have already obtained, and they can be found in 
%%     the file of "Pars_Data"

clear;
addpath(genpath('Algorithms'));
addpath(genpath('Linear_Regression'));
addpath(genpath('Pars_Selection'));
%% MSE
for iii=1:1:4
    clearvars -except iii
    noise_type = ['type',num2str(iii)]; 
    run_mse_cvparfor;
end
%% MCC
for iii=1:1:4
    clearvars -except iii
    noise_type = ['type',num2str(iii)]; 
    run_mcc_cvparfor;
end
%% MMCC
for iii=1:1:4
    clearvars -except iii
    noise_type = ['type',num2str(iii)]; 
    run_mmcc_cvparfor;
end
%% MCCVC
for iii=1:1:4
    clearvars -except iii
    noise_type = ['type',num2str(iii)]; 
    run_mccvc_cvparfor;
end
%% KMPE
for iii=1:1:4
    clearvars -except iii
    noise_type = ['type',num2str(iii)]; 
    run_kmpe_cvparfor;
end
%% QMEE
for iii=1:1:4
    clearvars -except iii
    noise_type = ['type',num2str(iii)]; 
    run_qmee_cvparfor;
end
%% QMEEF
for iii=1:1:4
    clearvars -except iii
    noise_type = ['type',num2str(iii)]; 
    run_qmeef_cvparfor;
end
%% MEEF without early stop
for iii=1:1:4
    clearvars -except iii
    noise_type = ['type',num2str(iii)]; 
    run_meef_NoEarlyStop_cvparfor;
end

delete(gcp);