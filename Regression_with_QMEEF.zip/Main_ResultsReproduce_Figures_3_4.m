%%  1. This code is used to reproduce the results of Figures 3 and 4 of the paper
%%  2. However, it should be noted that the training time shown in Figure 2 can be slighty influenced by the device you used

%clear;
clc;
close all;
addpath(genpath('Algorithms'));
addpath(genpath('Linear_Regression'));
addpath(genpath('Pars_Data'));
%% common settings
dataNum =500;
MC=20;
noiseType =[1, 2, 3, 4];
noise_rate = 0.1;
threshold0 =[0:0.1:2]';
maxIter=50; 
for t = 1: length(noiseType)
    iii = noiseType(t);
    noise_type = ['type',num2str(iii)]; 
    %%  Monte Carlo runs of QMEEF
    % Parameters Setting: the best parameters of MEEF are shared with QMEEF in Section 5.1.1.
    fileName = ['meef_parscv_noise_NoEarlyStop_', noise_type, '.mat']; 
    pars=importdata(fileName); 
    C = pars(1);
    lambda = pars(2);
    kermcc = pars(3);
    kerqmee = pars(4);
    for tt = 1:length(threshold0)
         threshold = threshold0(tt);
         rand('state', 1); % a random seed to reproduce the results
         randn('state', 0);% a random seed to reproduce the results
         for mc=1:MC
           % generate data 
            [train_x, train_y] = data_generate(dataNum);
            test_x = [];
            test_y = [];
            % introduce the noise
            ns = noise_regression(length(train_y), noise_rate, noise_type);
            train_y1=train_y+ns;
            [TrainTime1(mc), ~, ~, ~, RWEP1(mc)]= ...
                Linear_QMEEF_NoEarlyStop(train_x, train_y1, test_x, test_y, C, lambda, kermcc, kerqmee, threshold, maxIter);
         end
        Time_qmeef(tt) = mean(TrainTime1);
        RWEP_qmeef(tt) = mean(RWEP1);
    end
    
    pause(10); % a brief pause between the two methods to reduce mutual interference between them (when training time is recorded)
   %%  Monte Carlo runs of MEEF 
    % Parameters Setting
    fileName = ['meef_parscv_noise_NoEarlyStop_', noise_type, '.mat']; 
    pars=importdata(fileName); 
    C = pars(1);
    lambda = pars(2);
    kermcc = pars(3);
    kermee = pars(4);
    rand('state', 1); 
    randn('state', 0);
    for mc=1:MC
       % generate data 
        [train_x, train_y] = data_generate(dataNum);
        test_x = [];
        test_y = [];
        % introduce the noise
        ns = noise_regression(length(train_y), noise_rate, noise_type);
        train_y1=train_y+ns;
        [TrainTime2(mc), ~, ~, ~, RWEP2(mc)]= ...
                   Linear_MEEF_NoEarlyStop(train_x, train_y1, test_x, test_y, C, lambda, kermcc, kermee, maxIter);
    end
    Time_meef = mean(TrainTime2);
    RWEP_meef = mean(RWEP2);
    %%  figure: RMSE
    figure
    plot(threshold0, RWEP_qmeef, 'r-o', 'linewidth', 2);
    hold on
    plot(threshold0, RWEP_meef * ones(1,length(threshold0)), 'b:', 'linewidth', 2);
    set(gca, 'FontSize', 18);
    set(gca, 'FontName', 'Times New Roman');
    set(gcf,'color','w');
    legend('QMEEF', 'MEEF');
    grid on;
    xlabel('{ \epsilon}');       
    ylabel('{RWEP}');  
    figName = ['RWEP0', num2str(iii)];
    saveas(gcf, figName)
    %%  figure: Time
    figure
    plot(threshold0, Time_qmeef, 'r-o', 'linewidth', 2);
    hold on
    plot(threshold0, Time_meef * ones(1,length(threshold0)), 'b:', 'linewidth', 2);
    set(gca, 'FontSize', 18);
    set(gca, 'FontName', 'Times New Roman');
    set(gcf,'color','w');
    legend('QMEEF', 'MEEF');
    grid on;
    xlabel('{ \epsilon}');             
    ylabel('Training Time'); 
    figName = ['Time0', num2str(iii)];
    saveas(gcf, figName);
end
