%%   This code is used to reproduce the results of Table 1 of the paper

clear;
%% Get the root-weight-error-power (RWEP) of each compared method
% MSE
for iii=1:1:4
    clearvars -except iii
    noise_type = ['type',num2str(iii)]; 
    run_mse;
end
% MCC
for iii=1:1:4
    clearvars -except iii
    noise_type = ['type',num2str(iii)]; 
    run_mcc;
end
% MMCC
for iii=1:1:4
    clearvars -except iii
    noise_type = ['type',num2str(iii)]; 
    run_mmcc;
end
% MCCVC
for iii=1:1:4
    clearvars -except iii
    noise_type = ['type',num2str(iii)]; 
    run_mccvc;
end
% KMPE
for iii=1:1:4
    clearvars -except iii
    noise_type = ['type',num2str(iii)]; 
    run_kmpe;
end
% QMEE
for iii=1:1:4
    clearvars -except iii
    noise_type = ['type',num2str(iii)]; 
    run_qmee;
end
% QMEEF
for iii=1:1:4
    clearvars -except iii
    noise_type = ['type',num2str(iii)]; 
    run_qmeef;
end



%% Collect all the results in terms of RWEP
clear
MeanRWEP=[];
% MSE
V1=[];
for iii=1:1:4
   fileName = ['mse_noise_type', int2str(iii), '.mat']; 
   V=importdata(fileName);
   V1=[V1,V(:,end)];
end
MeanRWEP=[MeanRWEP; V1];
% MCC
V1=[];
for iii=1:1:4
   fileName = ['mcc_noise_type', int2str(iii), '.mat']; 
   V=importdata(fileName);
   V1=[V1,V(:,end)];
end
MeanRWEP=[MeanRWEP; V1];
% MMCC
V1=[];
for iii=1:1:4
   fileName = ['mmcc_noise_type', int2str(iii), '.mat']; 
   V=importdata(fileName);
   V1=[V1,V(:,end)];
end
MeanRWEP=[MeanRWEP; V1];
% MCC-VC
V1=[];
for iii=1:1:4
   fileName = ['mccvc_noise_type', int2str(iii), '.mat']; 
   V=importdata(fileName);
   V1=[V1,V(:,end)];
end
MeanRWEP=[MeanRWEP; V1];
% KMPE
V1=[];
for iii=1:1:4
   fileName = ['kmpe_noise_type', int2str(iii), '.mat']; 
   V=importdata(fileName);
   V1=[V1,V(:,end)];
end
MeanRWEP=[MeanRWEP; V1];
% QMEE
V1=[];
for iii=1:1:4
   fileName = ['qmee_noise_type', int2str(iii), '.mat']; 
   V=importdata(fileName);
   V1=[V1,V(:,end)];
end
MeanRWEP=[MeanRWEP; V1];
% QMEEF
V1=[];
for iii=1:1:4
   fileName = ['qmeef_noise_type', int2str(iii), '.mat']; 
   V=importdata(fileName);
   V1=[V1,V(:,end)];
end
MeanRWEP=[MeanRWEP; V1];
%
MeanRWEP=MeanRWEP'

