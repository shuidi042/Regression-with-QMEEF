%clear;
clc;
close all;
addpath(genpath('Algorithms'));
addpath(genpath('Linear_Regression'));
%%
dataNum =500;
MC=20;    
CV = 10;
if ~exist('noise_type','var')
    noise_type = 'type1';% noise type (if it is not specified, the fault choice is 'type1')
end
noise_rate = 0.1;
%% Parameters Setting
maxIter = 30; 
C = 10.^[-3:1:3];
sigmas1 = [0.02, 0.04, 0.06, 0.08, 0.1, 0.2, 0.4, 0.6, 0.8, 1, 2, 4, 6, 8, 10];
sigmas2 = [0.02, 0.04, 0.06, 0.08, 0.1, 0.2, 0.4, 0.6, 0.8, 1, 2, 4, 6, 8, 10];
alphas = [0, 1/5, 2/5, 3/5, 4/5, 5/5]; 
pars = [];
for i=1:length(C)
    for j=1:length(sigmas1)
        for k=1:length(sigmas2) 
            for m=1:length(alphas)
                 pars = [pars; C(i), sigmas1(j), sigmas2(k), alphas(m)];
            end
        end
    end
end
[parsLength, parsDimension] = size(pars);
clear C sigmas1 sigmas2  alphas 
%% Result for each group parameter
results=zeros(MC,CV,parsLength);
disp('The code is running. Please wait...');
tic;
parfor i=1:parsLength
    C(i) = pars(i, 1);
    sigma1(i) = pars(i, 2);
    sigma2(i) = pars(i, 3);
    alpha(i) = pars(i, 4);
    % for reproducing our results
    rand('state',1);% a random seed to reproduce the results
    randn('state',0);% a random seed to reproduce the results   
    % Monte Carlo
    for mc=1:MC
       %% generate data 
        [data_x, data_y] = data_generate(dataNum);
       %% introduce the noise 
        ns = noise_regression(dataNum, noise_rate, noise_type);
        data_y1=data_y+ns;
       %% Tenfold cross validation for Parameters selection 
        indices=crossvalind('Kfold',dataNum,CV);
        for cv=1:CV
            test_x=data_x(indices==cv,:);
            test_y=data_y1(indices==cv,:);
            train_x=data_x(indices~=cv,:);
            train_y=data_y1(indices~=cv,:);
            [~,~, ~, results(mc,cv,i),~]= Linear_MMCC(train_x, train_y, test_x, test_y, C(i), sigma1(i), sigma2(i), alpha(i), maxIter);
        end
    end 
end
toc;
%% Find the best parameters according to the results of Cross-Validation
accuracy=mean(mean(results,1),2);
[bestaccuracy,index] =min(accuracy);
pars1= pars(index,:);
tmp1=[pars1, bestaccuracy]; %
mmcc_parscv_noise= tmp1;
%% Store results
filename = ['mmcc_parscv_noise_',noise_type,'.mat'];
save(filename, 'mmcc_parscv_noise');
