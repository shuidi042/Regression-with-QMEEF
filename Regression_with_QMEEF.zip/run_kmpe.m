%clear;
clc;
close all;
addpath(genpath('Algorithms'));
addpath(genpath('Linear_Regression'));
addpath(genpath('Pars_Data'));
%%
dataNum =500;
MC=20;
if ~exist('noise_type','var')
    noise_type = 'type1';% noise type (if it is not specified, the fault choice is 'type1')
end
noise_rate = 0.1;
%% Parameters Setting
maxIter=30;  
fileName = ['kmpe_parscv_noise_', noise_type, '.mat']; 
pars=importdata(fileName); 
C = pars(1);
p = pars(2); 
sigma = pars(3);
%%  Monte Carlo runs
rand('state', 1);% a random seed to reproduce the results
randn('state', 0);% a random seed to reproduce the results
 for mc=1:MC
    %% generate data 
    [train_x, train_y] = data_generate(dataNum);
    test_x = [];
    test_y = [];
    %% introduce the noise
    ns = noise_regression(length(train_y), noise_rate, noise_type);
    train_y1=train_y+ns;
    [~, ~, ~, ~, RWEP(mc)]= Linear_KMPE(train_x, train_y1, test_x, test_y, C, p, sigma, maxIter);
 end
tmp1  = mean(RWEP)
kmpe_noise= tmp1;
%% Store results
filename = ['kmpe_noise_',noise_type,'.mat'];
save(filename, 'kmpe_noise');

