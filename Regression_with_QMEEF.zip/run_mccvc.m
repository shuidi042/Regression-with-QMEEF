%clear;
clc;
close all;
addpath(genpath('Algorithms'));
addpath(genpath('Linear_Regression'));
addpath(genpath('Pars_Data'));
%%
dataNum =500;
MC=20;
if ~exist('noise_type','var')
    noise_type = 'type1';% noise type (if it is not specified, the fault choice is 'type1')
end
noise_rate = 0.1;
%% Parameters Setting
fileName = ['mccvc_parscv_noise_', noise_type, '.mat']; 
maxIter =30;
pars=importdata(fileName); 
C = pars(1);
center = pars(2);
sigma = pars(3);
%%  Monte Carlo runs
rand('state', 1);% a random seed to reproduce the results
randn('state', 0);% a random seed to reproduce the results
 for mc=1:MC
    %% generate data 
    [train_x, train_y] = data_generate(dataNum);
    test_x = [];
    test_y = [];
    %% introduce the noise
    ns = noise_regression(length(train_y), noise_rate, noise_type);
    train_y1=train_y+ns;
    [~, ~, ~, ~, RWEP(mc)]= Linear_MCCVC(train_x, train_y1, test_x, test_y, C, center, sigma, maxIter);
 end
tmp1  = mean(RWEP)
mccvc_noise= tmp1;
%% Store results
filename = ['mccvc_noise_',noise_type,'.mat'];
save(filename, 'mccvc_noise');
